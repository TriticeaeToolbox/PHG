#!/bin/bash -x

# Edit the code below, replacing "${USER}" with your user handle
# Then replace "/workdir/${USER}/PHG_training_test/configSmallSeq.txt" with the
# path on your machine that contains the configSmallSeq.txt file
FOLDER="/Users/jj332/Google Drive/Teaching/WheatCAP/PHG/"

GENOME_DIR="${FOLDER}temp/"
if [ ! -d "${GENOME_DIR}" ]; then
	mkdir "${GENOME_DIR}"
fi
chmod 777 "${GENOME_DIR}"

# change the local mapping for the confiSmallSeq.txt file to match
# where it lives on your machine.
docker run --name cbsu_phg_container --rm \
	-v "${FOLDER}SmallSeqTest/configSmallSeq.txt":/tempFileDir/data/configSmallSeq.txt \
	-v "${GENOME_DIR}":/root/temp/\
	-t maizegenetics/phg:latest \
	/CreateSmallDataSet.sh /tempFileDir/data/configSmallSeq.txt

